# 💌 Pedido de Namoro — Site fofo com corações

Um site simples com animação de corações e uma “cartinha” que abre para fazer a pergunta: **Quer namorar comigo?** ✨

## Como publicar no GitHub Pages

### Opção 1 — Pelo site do GitHub (sem usar terminal)

1. Crie um repositório novo em https://github.com/new  
   **Nome sugerido:** `pedido-de-namoro`
2. Clique em **Add file ▸ Upload files** e envie o arquivo `index.html` desta pasta.
3. Vá em **Settings ▸ Pages**:
   - Em **Build and deployment**, em **Source**, escolha **Deploy from a branch**.
   - Em **Branch**, selecione `main` e a pasta `/ (root)`. Clique **Save**.
4. Volte em **Settings ▸ Pages** e veja o link do seu site (algo como `https://seu-usuario.github.io/pedido-de-namoro`). Pode levar 1–2 minutos para ficar no ar.

### Opção 2 — Pelo terminal (Windows PowerShell, macOS ou Linux)

```bash
# 1) Entre na pasta do projeto
cd caminho/para/pedido-de-namoro

# 2) Inicie o repositório e faça o primeiro commit
git init
git add index.html
git commit -m "Meu pedido de namoro 💘"

# 3) Crie o repositório no GitHub (no site) e copie a URL SSH ou HTTPS
# Exemplo (HTTPS):
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/pedido-de-namoro.git
git push -u origin main

# 4) Ative o GitHub Pages
# No GitHub: Settings ▸ Pages ▸ Source: Deploy from a branch
# Branch: main / (root) ▸ Save
```

## Personalização rápida

- Troque o título da aba em `<title>Tenho algo pra te dizer ❤️</title>`.
- Troque os textos dos botões `Sim ❤️` e `Claro que sim! 😍`.
- Quer música? Procure no YouTube por um MP3 livre de direitos, coloque como `musica.mp3` e adicione a tag:

```html
<audio autoplay loop>
  <source src="musica.mp3" type="audio/mpeg">
</audio>
```

> Dica: Se for usar música, é melhor hospedar no Netlify ou Vercel, pois o GitHub Pages não toca autoplay no iOS em alguns casos.

Boa sorte no pedido! 💞
